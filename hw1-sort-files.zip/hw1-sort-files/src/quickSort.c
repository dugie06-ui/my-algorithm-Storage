/* 퀵 정렬 — 수업 코드(topic-04 02_quick_sort)를 공통 인터페이스로 옮긴 것.
 *
 * 피벗 하나를 제자리에 놓고(파티션), 그 양쪽을 각각 정렬한다.
 * 나눌 때 일하고 합치는 것은 공짜다(병합 정렬과 반대).
 * 파티션은 수업과 같이 a[lo]를 피벗으로 쓰는 방식(로무토 파티션)이다.
 *
 * 피벗을 "고르는 법"만 quickSortPivot으로 바꿀 수 있게 했다. 기본값은 수업과
 * 같은 PIVOT_FIRST이고, 나머지 둘은 피벗 실험에서만 쓴다. 어느 방법이든
 * 고른 원소를 a[lo]로 옮겨 놓은 뒤 똑같은 파티션을 돈다.
 */
#include "sortctx.h"

QuickPivot quickSortPivot = PIVOT_FIRST;

const char *quickPivotName(QuickPivot pivot) {
    switch (pivot) {
        case PIVOT_FIRST:   return "first";
        case PIVOT_MEDIAN3: return "median3";
        case PIVOT_RANDOM:  return "random";
        default:            return "?";
    }
}

/* 무작위 피벗용 난수(xorshift64). rand()를 쓰지 않는 것은 입력을 만드는 난수와
 * 섞이지 않게 하려는 것이다. 정렬을 부를 때마다 같은 씨앗에서 시작하므로
 * 같은 입력이면 비교 횟수도 늘 같다. */
static unsigned long long pivotRng;

static size_t randomIndex(size_t lo, size_t hi) {
    pivotRng ^= pivotRng << 13;
    pivotRng ^= pivotRng >> 7;
    pivotRng ^= pivotRng << 17;
    return lo + (size_t)(pivotRng % (unsigned long long)(hi - lo + 1));
}

/* a[lo], a[mid], a[hi] 셋 중 가운데 값의 위치. 비교 2~3회 */
static size_t medianOfThree(SortCtx *c, size_t lo, size_t hi) {
    size_t mid = lo + (hi - lo) / 2;
    const char *x = sortAt(c, lo);
    const char *y = sortAt(c, mid);
    const char *z = sortAt(c, hi);
    if (sortCmp(c, x, y) < 0) {                   /* x < y */
        if (sortCmp(c, y, z) < 0) {
            return mid;                           /* x < y < z */
        }
        return sortCmp(c, x, z) < 0 ? hi : lo;    /* z가 x와 y 사이인가 */
    }
    if (sortCmp(c, x, z) < 0) {                   /* y <= x < z */
        return lo;
    }
    return sortCmp(c, y, z) < 0 ? hi : mid;       /* z가 y와 x 사이인가 */
}

static size_t choosePivot(SortCtx *c, size_t lo, size_t hi) {
    switch (quickSortPivot) {
        case PIVOT_MEDIAN3: return medianOfThree(c, lo, hi);
        case PIVOT_RANDOM:  return randomIndex(lo, hi);
        case PIVOT_FIRST:
        default:            return lo;
    }
}

/* 교환할 두 자리가 같으면 건너뛴다. 수업 코드의 swap과 같은 규칙 */
static void swapIfDifferent(SortCtx *c, size_t i, size_t j) {
    if (i != j) {
        sortSwap(c, i, j);
    }
}

/* 수업 코드의 Partition 그대로. a[lo]를 피벗으로 삼아, 피벗보다 작은 것은
 * 왼쪽에 모으고 피벗을 그 경계에 놓는다. 피벗의 최종 위치를 돌려준다.
 *
 * 조건이 '<'라서 피벗과 같은 값은 오른쪽에 남는다. 그래서 값이 모두 같은
 * 구간에서는 피벗이 늘 맨 왼쪽에 서고 한쪽만 남는다 — 중복이 많을 때
 * 느려지는 이유다(보고서 3.2절). */
static size_t partition(SortCtx *c, size_t lo, size_t hi) {
    size_t i = lo; /* a[lo+1..i]: 피벗보다 작은 구간의 끝 */
    for (size_t j = lo + 1; j <= hi; j++) {
        if (sortCmp(c, sortAt(c, j), sortAt(c, lo)) < 0) {
            i++;
            swapIfDifferent(c, i, j); /* 멀리 뛰는 교환 — 불안정해지는 이유 */
        }
    }
    swapIfDifferent(c, lo, i); /* 피벗을 경계로 */
    return i;
}

static void quickSortRange(SortCtx *c, size_t lo, size_t hi, size_t depth) {
    if (lo >= hi) {
        return; /* 원소가 0~1개면 이미 정렬 */
    }
    sortEnterDepth(c, depth);
    swapIfDifferent(c, lo, choosePivot(c, lo, hi)); /* 고른 피벗을 a[lo]로 */
    size_t p = partition(c, lo, hi);
    if (p > lo) {
        quickSortRange(c, lo, p - 1, depth + 1); /* 피벗 왼쪽 (더 작은 것들) */
    }
    quickSortRange(c, p + 1, hi, depth + 1);     /* 피벗 오른쪽 (크거나 같은 것들) */
}

void quickSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats) {
    SortCtx c;
    if (!sortBegin(&c, base, n, size, cmp, stats, 1)) { /* 교환용 원소 1칸 */
        return;
    }
    pivotRng = 0x9E3779B97F4A7C15ULL; /* 부를 때마다 같은 씨앗 */
    quickSortRange(&c, 0, n - 1, 1);
    sortEnd(&c);
}
