/* 공통 토대 — 구현 셋이 함께 쓰는 도구와, 그 구현들을 모아 둔 표.
 *
 * 정렬 자체는 각자 제 파일에 있다: quickSort.c · mergeSort.c · heapSort.c
 */
#include "sort.h"

#include <stdlib.h>

#include "sortctx.h"

void sortStatsReset(SortStats *stats) {
    if (stats == NULL) {
        return;
    }
    stats->compares = 0;
    stats->moves = 0;
    stats->extraBytes = 0;
    stats->maxDepth = 1; /* 재귀를 쓰지 않아도 깊이는 1로 센다 */
}

int sortCompareInt(const void *a, const void *b) {
    int x = *(const int *)a;
    int y = *(const int *)b;
    return (x > y) - (x < y); /* x - y는 overflow가 날 수 있어 쓰지 않는다 */
}

int sortBegin(SortCtx *c, void *base, size_t n, size_t size,
              SortCompare cmp, SortStats *stats, size_t bufElems) {
    sortStatsReset(stats);
    if (base == NULL || cmp == NULL || size == 0 || n < 2 || bufElems == 0) {
        return 0;
    }
    c->base = (char *)base;
    c->size = size;
    c->cmp = cmp;
    c->stats = stats;
    c->buf = (char *)malloc(bufElems * size);
    if (c->buf == NULL) {
        return 0;
    }
    if (stats != NULL) {
        stats->extraBytes = bufElems * size;
    }
    return 1;
}

void sortEnd(SortCtx *c) {
    free(c->buf);
    c->buf = NULL;
}

/* --- 구현 표 ----------------------------------------------------------- */

/* 정렬을 하나 더 만들면 파일을 하나 더 두고 여기에 한 줄 넣는다.
 * main.c도 테스트도 이 표만 훑으므로 그것으로 끝이다. */
const SortAlgorithm SORT_ALGORITHMS[] = {
    /* 이름         평균          최악          추가 메모리  안정  함수 */
    {"quickSort", "O(n log n)", "O(n^2)",     "O(log n)", 0, quickSort},
    {"mergeSort", "O(n log n)", "O(n log n)", "O(n)",     1, mergeSort},
    {"heapSort",  "O(n log n)", "O(n log n)", "O(1)",     0, heapSort},
};

const size_t SORT_ALGORITHM_COUNT = sizeof(SORT_ALGORITHMS) / sizeof(SORT_ALGORITHMS[0]);
