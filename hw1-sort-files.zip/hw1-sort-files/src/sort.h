/* 정렬 비교 과제 — 퀵 · 병합 · 힙 정렬을 하나의 공통 인터페이스로 묶는다.
 *
 * C에는 interface가 없다. 대신 함수 포인터를 담은 구조체(SortAlgorithm)를 쓴다.
 * 비교 규약은 표준 라이브러리 qsort와 같게 맞춰, 정렬이 원소의 타입을 몰라도
 * 되게 했다. 덕분에 int 배열도, (key, tag) 레코드 배열도 같은 코드로 정렬한다.
 */
#ifndef SORT_H
#define SORT_H

#include <stddef.h>

/* qsort와 같은 규약: a<b면 음수, a==b면 0, a>b면 양수 */
typedef int (*SortCompare)(const void *a, const void *b);

/* 정렬 한 번 동안 모은 측정값. 시계와 무관하게 재현되는 값만 담는다.
 * (시간은 바깥의 bench.c가 잰다.) */
typedef struct SortStats {
    size_t compares;   /* 비교 함수를 부른 횟수 */
    size_t moves;      /* 원소 한 개를 복사한 횟수. 교환 한 번은 3 */
    size_t extraBytes; /* 입력 배열 밖에 잡은 작업 공간(바이트). 재귀 스택은 제외 */
    size_t maxDepth;   /* 재귀 깊이의 최댓값. 반복문만 쓰면 1 */
} SortStats;

typedef void (*SortFunction)(void *base, size_t n, size_t size,
                             SortCompare cmp, SortStats *stats);

/* 정렬 한 가지 = 이 구조체 값 하나. 자바의 "interface 구현체"에 해당한다. */
typedef struct SortAlgorithm {
    const char *name;
    const char *avgTime;   /* 평균 시간복잡도 */
    const char *worstTime; /* 최악 시간복잡도 */
    const char *space;     /* 추가 메모리 */
    int stable;            /* 안정 정렬이라고 "주장"하는 값. 테스트가 실측과 맞춰 본다 */
    SortFunction sort;     /* base[0..n-1]을 오름차순으로. stats가 NULL이면 세지 않는다 */
} SortAlgorithm;

void quickSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats);
void mergeSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats);
void heapSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats);

/* 구현 표. 부르는 쪽(main.c, 테스트)은 정렬 이름을 적지 않고 이 표만 훑는다. */
extern const SortAlgorithm SORT_ALGORITHMS[];
extern const size_t SORT_ALGORITHM_COUNT;

/* 퀵 정렬의 피벗 고르는 법. 기본은 수업 코드와 같은 "첫 원소"다.
 * 피벗 실험(main.c)과 테스트만 이 값을 바꿔 본다. */
typedef enum QuickPivot {
    PIVOT_FIRST,   /* a[lo] — 수업 코드 그대로 */
    PIVOT_MEDIAN3, /* a[lo], a[mid], a[hi] 셋의 중앙값 */
    PIVOT_RANDOM,  /* lo..hi 중 무작위 (씨앗 고정) */
    PIVOT_KIND_COUNT
} QuickPivot;

extern QuickPivot quickSortPivot;
const char *quickPivotName(QuickPivot pivot);

void sortStatsReset(SortStats *stats);
int sortCompareInt(const void *a, const void *b); /* int 배열용 비교 함수 */

#endif /* SORT_H */
