/* 정렬 비교 실행기 — 실험 네 가지를 같은 잣대로 돌린다.
 *
 *   ./src/main.out          사람이 읽는 표 (make run)
 *   ./src/main.out --csv    같은 측정을 CSV로 (make charts가 읽는다)
 *
 * 무엇을 잴지는 아래 run- 함수 네 곳에만 적혀 있다. 결과를 표로 찍을지 CSV로
 * 찍을지는 출력 함수 포인터(RowSink) 하나로 갈아 끼운다. 정렬을 구현 표로
 * 갈아 끼운 것과 같은 수다.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bench.h"
#include "sort.h"

enum {
    SHAPE_N = 10000, /* 입력 모양 실험과 피벗 실험의 크기 */
    SEED = 20260930, /* 입력 씨앗. 고정이라 비교·이동 횟수는 언제 돌려도 같다 */
    REPS = 5         /* 시간을 몇 번 재서 중앙값을 낼지 */
};

typedef struct Row {
    const char *experiment; /* shape · growth · worst · pivot */
    InputKind kind;
    const char *algo;
    const char *pivot; /* 퀵 정렬의 피벗 고르는 법. 다른 정렬은 "-" */
    BenchResult r;
} Row;

typedef void (*RowSink)(const Row *row);

/* --- 출력: CSV ------------------------------------------------------------ */

static const char *stableText(int stable) {
    return stable < 0 ? "na" : (stable ? "yes" : "no");
}

static void csvSink(const Row *w) {
    printf("%s,%s,%s,%s,%zu,%.4f,%zu,%zu,%zu,%zu,%s,%s\n",
           w->experiment, inputKindId(w->kind), w->algo, w->pivot, w->r.n,
           w->r.millis, w->r.stats.compares, w->r.stats.moves,
           w->r.stats.extraBytes, w->r.stats.maxDepth,
           w->r.sorted ? "yes" : "no", stableText(w->r.stable));
}

/* --- 출력: 사람이 읽는 표 --------------------------------------------------- */

/* 터미널에서 한글은 두 칸을 차지한다. printf의 폭은 바이트를 세므로 직접 센다. */
static int displayWidth(const char *s) {
    int w = 0;
    for (const unsigned char *p = (const unsigned char *)s; *p != '\0'; p++) {
        if ((*p & 0xC0) == 0x80) {
            continue; /* UTF-8의 이어지는 바이트 */
        }
        w += (*p >= 0xE0) ? 2 : 1;
    }
    return w;
}

static void printCell(const char *s, int width, int alignRight) {
    int pad = width - displayWidth(s);
    if (pad < 0) {
        pad = 0;
    }
    if (alignRight) {
        printf("%*s%s", pad, "", s);
    } else {
        printf("%s%*s", s, pad, "");
    }
}

/* 1234567 -> "1,234,567" */
static const char *withCommas(size_t v, char *buf, size_t cap) {
    char digits[32];
    int len = snprintf(digits, sizeof digits, "%zu", v);
    size_t out = 0;
    for (int i = 0; i < len && out + 1 < cap; i++) {
        if (i > 0 && (len - i) % 3 == 0 && out + 2 < cap) {
            buf[out++] = ',';
        }
        buf[out++] = digits[i];
    }
    buf[out] = '\0';
    return buf;
}

static const char *experimentTitle(const char *experiment) {
    if (strcmp(experiment, "shape") == 0)  return "1. 입력 모양별 비교 (n = 10,000)";
    if (strcmp(experiment, "growth") == 0) return "2. n을 키우며 (무작위 입력)";
    if (strcmp(experiment, "worst") == 0)  return "3. 정렬된 입력에서 n을 키우며";
    if (strcmp(experiment, "pivot") == 0)  return "4. 추가 실험 — 퀵 정렬의 피벗 고르는 법 (n = 10,000)";
    return experiment;
}

static void tableHeader(void) {
    printf("  ");
    printCell("알고리즘", 18, 0);
    printCell("시간(ms)", 10, 1);
    printCell("비교", 15, 1);
    printCell("이동", 15, 1);
    printCell("추가 메모리", 13, 1);
    printCell("재귀 깊이", 11, 1);
    printCell("정렬", 7, 1);
    printCell("안정", 7, 1);
    printf("\n  ");
    for (int i = 0; i < 96; i++) {
        putchar('-');
    }
    putchar('\n');
}

static void tableSink(const Row *w) {
    static const char *lastExperiment = NULL;
    static int lastKind = -1;
    static size_t lastN = 0;
    char a[32], b[32], c[32], d[32];

    if (lastExperiment == NULL || strcmp(lastExperiment, w->experiment) != 0) {
        printf("\n=== %s ===\n", experimentTitle(w->experiment));
        lastKind = -1;
    }
    if ((int)w->kind != lastKind || w->r.n != lastN ||
        lastExperiment == NULL || strcmp(lastExperiment, w->experiment) != 0) {
        printf("\n[%s · n = %s]\n", inputKindName(w->kind), withCommas(w->r.n, a, sizeof a));
        tableHeader();
    }
    lastExperiment = w->experiment;
    lastKind = (int)w->kind;
    lastN = w->r.n;

    char name[48];
    if (strcmp(w->experiment, "pivot") == 0) {
        snprintf(name, sizeof name, "%s/%s", w->algo, w->pivot);
    } else {
        snprintf(name, sizeof name, "%s", w->algo);
    }
    char e[32];
    snprintf(d, sizeof d, "%s B", withCommas(w->r.stats.extraBytes, e, sizeof e));
    printf("  %-18s %9.3f %14s %14s %12s %10s %6s %6s\n", name, w->r.millis,
           withCommas(w->r.stats.compares, a, sizeof a),
           withCommas(w->r.stats.moves, b, sizeof b), d,
           withCommas(w->r.stats.maxDepth, c, sizeof c),
           w->r.sorted ? "yes" : "NO", w->r.stable < 0 ? "-" : (w->r.stable ? "yes" : "no"));
}

/* --- 실험 ----------------------------------------------------------------- */

static void emit(RowSink sink, const char *experiment, InputKind kind,
                 const SortAlgorithm *algo, const Record *input, size_t n, int reps) {
    Row w;
    w.experiment = experiment;
    w.kind = kind;
    w.algo = algo->name;
    w.pivot = (algo->sort == quickSort) ? quickPivotName(quickSortPivot) : "-";
    w.r = benchRun(algo, input, n, reps);
    sink(&w);
}

static Record *newInput(size_t n) {
    Record *a = (Record *)malloc(n * sizeof *a);
    if (a == NULL) {
        fprintf(stderr, "메모리가 부족합니다 (n = %zu)\n", n);
        exit(1);
    }
    return a;
}

/* 1. 같은 n에서 입력 모양 다섯 가지 */
static void runShapes(RowSink sink) {
    Record *input = newInput(SHAPE_N);
    for (int k = 0; k < INPUT_KIND_COUNT; k++) {
        makeInput(input, SHAPE_N, (InputKind)k, SEED);
        for (size_t a = 0; a < SORT_ALGORITHM_COUNT; a++) {
            emit(sink, "shape", (InputKind)k, &SORT_ALGORITHMS[a], input, SHAPE_N, REPS);
        }
    }
    free(input);
}

/* 2. 무작위 입력에서 n을 1,000부터 1,024,000까지 두 배씩.
 *    큰 n은 한 번이 충분히 길어 흔들림이 작으므로 3회만 잰다(실행 시간 절약). */
static void runGrowth(RowSink sink) {
    for (size_t n = 1000; n <= 1024000; n *= 2) {
        Record *input = newInput(n);
        makeInput(input, n, INPUT_RANDOM, SEED);
        for (size_t a = 0; a < SORT_ALGORITHM_COUNT; a++) {
            emit(sink, "growth", INPUT_RANDOM, &SORT_ALGORITHMS[a], input, n,
                 n >= 128000 ? 3 : REPS);
        }
        free(input);
    }
}

/* 3. 정렬된 입력에서 n을 1,000부터 16,000까지 — 퀵 정렬의 최악 O(n^2)을 본다.
 *    더 키우지 않는 것은 퀵 정렬이 n을 두 배로 할 때마다 네 배씩 느려지고,
 *    재귀 깊이도 n-1까지 가서 스택이 위험해지기 때문이다. */
static void runWorst(RowSink sink) {
    for (size_t n = 1000; n <= 16000; n *= 2) {
        Record *input = newInput(n);
        makeInput(input, n, INPUT_SORTED, SEED);
        for (size_t a = 0; a < SORT_ALGORITHM_COUNT; a++) {
            emit(sink, "worst", INPUT_SORTED, &SORT_ALGORITHMS[a], input, n, 3);
        }
        free(input);
    }
}

/* 4. 퀵 정렬만, 피벗 고르는 법 세 가지 × 입력 모양 다섯 가지 */
static void runPivots(RowSink sink) {
    const SortAlgorithm *quick = NULL;
    for (size_t a = 0; a < SORT_ALGORITHM_COUNT; a++) {
        if (SORT_ALGORITHMS[a].sort == quickSort) {
            quick = &SORT_ALGORITHMS[a];
        }
    }
    if (quick == NULL) {
        return;
    }
    Record *input = newInput(SHAPE_N);
    for (int k = 0; k < INPUT_KIND_COUNT; k++) {
        makeInput(input, SHAPE_N, (InputKind)k, SEED);
        for (int p = 0; p < PIVOT_KIND_COUNT; p++) {
            quickSortPivot = (QuickPivot)p;
            emit(sink, "pivot", (InputKind)k, quick, input, SHAPE_N, REPS);
        }
    }
    quickSortPivot = PIVOT_FIRST; /* 기본값으로 되돌린다 */
    free(input);
}

int main(int argc, char **argv) {
    int csv = (argc > 1 && strcmp(argv[1], "--csv") == 0);
    RowSink sink = csv ? csvSink : tableSink;

    if (csv) {
        printf("experiment,input,algorithm,pivot,n,ms,compares,moves,"
               "extra_bytes,max_depth,sorted,stable\n");
    } else {
        printf("=== 정렬 비교: 퀵 · 병합 · 힙 ===\n\n");
        printf("  %-10s %-11s %-11s %-9s %s\n", "name", "avg", "worst", "space", "stable");
        for (size_t a = 0; a < SORT_ALGORITHM_COUNT; a++) {
            const SortAlgorithm *s = &SORT_ALGORITHMS[a];
            printf("  %-10s %-11s %-11s %-9s %s\n", s->name, s->avgTime, s->worstTime,
                   s->space, s->stable ? "yes" : "no");
        }
        printf("\n  시간: %d회 중앙값(카운터를 끈 채로) · 비교·이동: 입력이 고정이라 재현됨\n", REPS);
        printf("  안정: 같은 key의 입력 순서가 남았나(실측). 같은 key가 없는 입력은 '-'\n");
    }

    runShapes(sink);
    runGrowth(sink);
    runWorst(sink);
    runPivots(sink);
    return 0;
}
