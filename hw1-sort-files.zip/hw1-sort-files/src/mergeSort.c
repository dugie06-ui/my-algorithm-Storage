/* 병합 정렬 — 수업 코드(topic-03 01_merge_sort)를 공통 인터페이스로 옮긴 것.
 *
 * 반으로 나눠 각각 정렬하고, 정렬된 두 절반을 하나로 합친다.
 * 나누는 것은 공짜고 합칠 때 일한다(퀵 정렬과 반대).
 * 합치는 동안 원소를 잠시 담아 둘 temp가 원소 n칸 필요하다.
 */
#include "sortctx.h"

/* a[lo..mid]와 a[mid+1..hi]가 각각 정렬된 상태에서 하나로 합친다.
 * temp로 한 번, 다시 a로 한 번 옮기므로 원소마다 이동 2회다. */
static void merge(SortCtx *c, size_t lo, size_t mid, size_t hi) {
    char *temp = c->buf;
    size_t i = lo;
    size_t j = mid + 1;
    size_t k = lo;
    while (i <= mid && j <= hi) {
        /* '<='라서 같은 값이면 왼쪽이 먼저 나간다 — 이 한 글자가 안정성을 만든다 */
        if (sortCmp(c, sortAt(c, i), sortAt(c, j)) <= 0) {
            sortMove(c, temp + k * c->size, sortAt(c, i));
            i++;
        } else {
            sortMove(c, temp + k * c->size, sortAt(c, j));
            j++;
        }
        k++;
    }
    while (i <= mid) { /* 왼쪽에 남은 것 */
        sortMove(c, temp + k * c->size, sortAt(c, i));
        i++;
        k++;
    }
    while (j <= hi) { /* 오른쪽에 남은 것 */
        sortMove(c, temp + k * c->size, sortAt(c, j));
        j++;
        k++;
    }
    for (k = lo; k <= hi; k++) { /* temp에서 a로 되돌린다 */
        sortMove(c, sortAt(c, k), temp + k * c->size);
    }
}

static void mergeSortRange(SortCtx *c, size_t lo, size_t hi, size_t depth) {
    if (lo >= hi) {
        return;
    }
    sortEnterDepth(c, depth);
    size_t mid = lo + (hi - lo) / 2;
    mergeSortRange(c, lo, mid, depth + 1);
    mergeSortRange(c, mid + 1, hi, depth + 1);
    merge(c, lo, mid, hi);
}

void mergeSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats) {
    SortCtx c;
    if (!sortBegin(&c, base, n, size, cmp, stats, n)) { /* temp: 원소 n칸 */
        return;
    }
    mergeSortRange(&c, 0, n - 1, 1);
    sortEnd(&c);
}
