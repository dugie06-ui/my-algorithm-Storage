#include "bench.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int recordCompare(const void *a, const void *b) {
    int x = ((const Record *)a)->key;
    int y = ((const Record *)b)->key;
    return (x > y) - (x < y);
}

const char *inputKindId(InputKind kind) {
    switch (kind) {
        case INPUT_RANDOM:     return "random";
        case INPUT_SORTED:     return "sorted";
        case INPUT_REVERSED:   return "reversed";
        case INPUT_NEARLY:     return "nearly";
        case INPUT_FEW_UNIQUE: return "fewunique";
        default:               return "?";
    }
}

const char *inputKindName(InputKind kind) {
    switch (kind) {
        case INPUT_RANDOM:     return "무작위";
        case INPUT_SORTED:     return "정렬됨";
        case INPUT_REVERSED:   return "역순";
        case INPUT_NEARLY:     return "거의 정렬됨";
        case INPUT_FEW_UNIQUE: return "중복 많음";
        default:               return "?";
    }
}

/* 입력용 난수 — xorshift32. 표준 rand()는 운영체제마다 수열이 달라서,
 * 어디서 돌려도 같은 입력이 나오도록 직접 두었다. */
static uint32_t rngState = 1;

static uint32_t rngNext(void) {
    uint32_t x = rngState;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rngState = x;
    return x;
}

void makeInput(Record *a, size_t n, InputKind kind, unsigned seed) {
    rngState = seed != 0 ? (uint32_t)seed : 1u;
    for (size_t i = 0; i < n; i++) {
        switch (kind) {
            case INPUT_RANDOM:     a[i].key = (int)(rngNext() >> 1); break; /* 0 ~ 2^31-1 */
            case INPUT_REVERSED:   a[i].key = (int)(n - 1 - i); break;
            case INPUT_FEW_UNIQUE: a[i].key = (int)(rngNext() % 10); break;
            case INPUT_SORTED:
            case INPUT_NEARLY:
            default:               a[i].key = (int)i; break;
        }
        a[i].tag = (int)i; /* 입력에서의 순서를 새겨 둔다 */
    }
    if (kind == INPUT_NEARLY) { /* 정렬된 배열에서 n/100쌍만 흐트러뜨린다 */
        for (size_t s = 0; s < n / 100; s++) {
            size_t i = rngNext() % n;
            size_t j = rngNext() % n;
            int t = a[i].key;
            a[i].key = a[j].key;
            a[j].key = t;
        }
    }
}

int recordsSorted(const Record *a, size_t n) {
    for (size_t i = 1; i < n; i++) {
        if (a[i - 1].key > a[i].key) {
            return 0;
        }
    }
    return 1;
}

int recordsStable(const Record *a, size_t n) {
    for (size_t i = 1; i < n; i++) {
        if (a[i - 1].key == a[i].key && a[i - 1].tag > a[i].tag) {
            return 0;
        }
    }
    return 1;
}

int recordsHaveTies(const Record *a, size_t n) {
    for (size_t i = 1; i < n; i++) {
        if (a[i - 1].key == a[i].key) {
            return 1;
        }
    }
    return 0;
}

/* --- 시간 -------------------------------------------------------------- */

static double nowMillis(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC); /* C11 표준. clock()보다 해상도가 좋다 */
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

static int compareDouble(const void *a, const void *b) {
    double x = *(const double *)a;
    double y = *(const double *)b;
    return (x > y) - (x < y);
}

enum { BENCH_MAX_REPS = 15 };

BenchResult benchRun(const SortAlgorithm *algo, const Record *input, size_t n, int reps) {
    BenchResult r;
    memset(&r, 0, sizeof r);
    r.n = n;
    r.stable = -1;
    sortStatsReset(&r.stats);
    if (reps < 1) {
        reps = 1;
    }
    if (reps > BENCH_MAX_REPS) {
        reps = BENCH_MAX_REPS;
    }

    Record *work = (Record *)malloc((n > 0 ? n : 1) * sizeof *work);
    if (work == NULL) {
        return r;
    }

    /* 1) 세기: 카운터를 켜고 한 번. 입력이 고정이라 이 값은 재현된다. */
    memcpy(work, input, n * sizeof *work);
    algo->sort(work, n, sizeof *work, recordCompare, &r.stats);
    r.sorted = recordsSorted(work, n);
    if (recordsHaveTies(work, n)) {
        r.stable = recordsStable(work, n);
    }

    /* 2) 시간: 카운터를 끄고(stats = NULL) reps번. 복사가 끝난 뒤부터 잰다. */
    double times[BENCH_MAX_REPS];
    for (int t = 0; t < reps; t++) {
        memcpy(work, input, n * sizeof *work);
        double begin = nowMillis();
        algo->sort(work, n, sizeof *work, recordCompare, NULL);
        times[t] = nowMillis() - begin;
    }
    qsort(times, (size_t)reps, sizeof times[0], compareDouble);
    r.millis = times[reps / 2]; /* 중앙값: 한 번 튄 값에 끌려가지 않는다 */

    free(work);
    return r;
}
