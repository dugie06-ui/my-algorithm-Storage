/* 세 정렬을 같은 잣대로 재는 도구.
 *
 * 알고리즘(sort.c 등)과 측정(bench.c)을 나눠 둔다. 정렬은 자기가 측정당하는
 * 줄 모르고, 측정은 어떤 정렬인지 모른다. 둘을 잇는 것은 SortAlgorithm뿐이다.
 */
#ifndef BENCH_H
#define BENCH_H

#include <stddef.h>

#include "sort.h"

/* 측정용 원소. key로 정렬하고, tag에는 입력에서의 순서를 새겨 둔다.
 * 정렬 뒤 같은 key끼리 tag가 오름차순이면 그 실행은 안정했다.
 * key만 있는 int 배열로는 3과 3을 구별할 수 없어 안정성을 볼 수 없다. */
typedef struct Record {
    int key;
    int tag;
} Record;

/* key만 본다. tag까지 비교하면 모든 정렬이 안정해 보인다. */
int recordCompare(const void *a, const void *b);

/* 입력 모양. 같은 정렬도 입력에 따라 성능이 크게 달라진다. */
typedef enum InputKind {
    INPUT_RANDOM,     /* 무작위 */
    INPUT_SORTED,     /* 이미 정렬됨 */
    INPUT_REVERSED,   /* 역순 */
    INPUT_NEARLY,     /* 거의 정렬됨: 정렬된 배열에서 n/100쌍을 무작위로 맞바꿈 */
    INPUT_FEW_UNIQUE, /* 중복 많음: 값이 0~9 열 가지뿐 */
    INPUT_KIND_COUNT
} InputKind;

const char *inputKindId(InputKind kind);   /* CSV용 영문 이름 */
const char *inputKindName(InputKind kind); /* 표에 찍는 한글 이름 */

/* a[0..n-1]을 kind 모양으로 채운다. seed가 같으면 어디서 돌려도 같은 입력이 나온다. */
void makeInput(Record *a, size_t n, InputKind kind, unsigned seed);

int recordsSorted(const Record *a, size_t n);    /* key가 오름차순인가 */
int recordsStable(const Record *a, size_t n);    /* 같은 key끼리 tag 순서가 남았는가 */
int recordsHaveTies(const Record *a, size_t n);  /* 정렬된 a에 같은 key가 있는가 */

typedef struct BenchResult {
    size_t n;
    double millis;   /* reps번 잰 시간의 중앙값 (카운터를 끈 채로 잰다) */
    SortStats stats; /* 비교·이동 등. 입력이 같으면 언제 돌려도 같다 */
    int sorted;      /* 결과가 정말 정렬됐는가 — 측정값보다 이것이 먼저다 */
    int stable;      /* 1 안정, 0 불안정, -1 같은 key가 없어 판정할 수 없음 */
} BenchResult;

/* input을 복사해 reps번 정렬하고 시간의 중앙값을 남긴다. 복사 시간은 빼고 잰다. */
BenchResult benchRun(const SortAlgorithm *algo, const Record *input, size_t n, int reps);

#endif /* BENCH_H */
