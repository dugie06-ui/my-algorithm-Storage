/* 힙 정렬 — 수업에서 다루지 않은 정렬. AI로 학습한 내용은 보고서 2.3절에 있다.
 *
 * 배열을 "완전 이진 트리"로 본다. 0부터 번호를 매기면
 *     i의 왼쪽 자식 = 2i+1,  오른쪽 자식 = 2i+2,  부모 = (i-1)/2
 * 이므로 포인터도 추가 배열도 필요 없다.
 *
 *   1단계 (힙 만들기)  자식이 있는 마지막 노드(n/2-1)부터 루트까지 거꾸로 가며
 *                      하나씩 가라앉혀, 모든 부모가 자식 이상인 "최대 힙"을 만든다. O(n)
 *   2단계 (꺼내기)     루트(최댓값)를 배열 끝으로 보내 자리를 확정하고, 한 칸 줄어든
 *                      힙에서 새 루트를 가라앉힌다. 이것을 n-1번 반복한다. O(n log n)
 *
 * 선택 정렬과 뼈대가 같다(최댓값을 골라 끝으로 보낸다). 다만 최댓값을 찾는 데
 * O(n)이 아니라 O(log n)이 든다. 재귀가 없고, 작업 공간은 원소 한 칸(buf)뿐이다.
 */
#include "sortctx.h"

/* buf에 들어 있는 원소를 hole 자리부터 가라앉혀 a[0..n-1]의 힙 조건을 되살린다.
 *
 * 교환 대신 "구멍"을 내려보낸다. 더 큰 자식을 구멍으로 끌어올리고, 구멍이
 * 멈춘 자리에 buf를 한 번만 놓는다. 삽입 정렬이 원소를 밀어내는 것과 같은 수다.
 * 교환으로 하면 한 단계에 이동 3회, 이렇게 하면 1회다. */
static void siftDown(SortCtx *c, size_t hole, size_t n) {
    for (;;) {
        size_t child = 2 * hole + 1; /* 왼쪽 자식 */
        if (child >= n) {
            break; /* 잎에 닿았다 */
        }
        if (child + 1 < n && sortCmp(c, sortAt(c, child + 1), sortAt(c, child)) > 0) {
            child++; /* 오른쪽 자식이 더 크다 */
        }
        if (sortCmp(c, sortAt(c, child), c->buf) <= 0) {
            break; /* 더 큰 자식도 buf보다 크지 않다: 여기가 제자리 */
        }
        sortMove(c, sortAt(c, hole), sortAt(c, child)); /* 자식을 구멍으로 끌어올린다 */
        hole = child;
    }
    sortMove(c, sortAt(c, hole), c->buf);
}

void heapSort(void *base, size_t n, size_t size, SortCompare cmp, SortStats *stats) {
    SortCtx c;
    if (!sortBegin(&c, base, n, size, cmp, stats, 1)) { /* 구멍에 담아 둘 원소 1칸 */
        return;
    }

    /* 1단계: 아래에서 위로 힙 만들기. 잎(n/2..n-1)은 이미 크기 1짜리 힙이다. */
    for (size_t i = n / 2; i-- > 0;) {
        sortMove(&c, c.buf, sortAt(&c, i));
        siftDown(&c, i, n);
    }

    /* 2단계: 최댓값을 하나씩 끝으로 보낸다. a[end..n-1]은 정렬이 끝난 구간이다. */
    for (size_t end = n - 1; end > 0; end--) {
        sortMove(&c, c.buf, sortAt(&c, end));        /* 끝 원소를 들어내고 */
        sortMove(&c, sortAt(&c, end), sortAt(&c, 0)); /* 최댓값을 끝에 확정한 뒤 */
        siftDown(&c, 0, end);                         /* 들어낸 원소를 루트부터 가라앉힌다 */
    }

    sortEnd(&c);
}
