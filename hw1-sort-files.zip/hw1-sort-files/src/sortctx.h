/* 정렬 구현끼리만 쓰는 작업 문맥 — 구현 전용 헤더.
 *
 * sort.h가 바깥에 보이는 인터페이스라면, 이쪽은 구현들이 함께 쓰는 도구다.
 * 세 정렬은 비교와 이동을 반드시 아래 함수로만 한다. 그래야 셋이 똑같은
 * 방법으로 세어지고, 비교 횟수를 서로 견줄 수 있다.
 * 원소마다 불리는 함수라 static inline으로 두었다.
 */
#ifndef SORTCTX_H
#define SORTCTX_H

#include <stddef.h>
#include <string.h>

#include "sort.h"

typedef struct SortCtx {
    char *base;       /* 배열의 첫 바이트 */
    size_t size;      /* 원소 하나의 바이트 수 */
    SortCompare cmp;
    SortStats *stats;
    char *buf;        /* 작업 공간. 퀵·힙은 원소 1칸, 병합은 n칸 */
} SortCtx;

/* 작업 공간을 원소 bufElems칸 잡고 문맥을 채운다. 정렬할 것이 없으면(n < 2)
 * 0을 돌려주고, 그때는 sortEnd를 부르지 않는다. */
int sortBegin(SortCtx *c, void *base, size_t n, size_t size,
              SortCompare cmp, SortStats *stats, size_t bufElems);
void sortEnd(SortCtx *c);

static inline char *sortAt(const SortCtx *c, size_t i) {
    return c->base + i * c->size;
}

/* 원소 두 개를 비교한다. 비교는 전부 여기를 거친다. */
static inline int sortCmp(SortCtx *c, const void *a, const void *b) {
    if (c->stats != NULL) {
        c->stats->compares++;
    }
    return c->cmp(a, b);
}

/* 원소 한 개를 src에서 dst로 옮겨 적는다. 이동은 전부 여기를 거친다. */
static inline void sortMove(SortCtx *c, void *dst, const void *src) {
    memcpy(dst, src, c->size);
    if (c->stats != NULL) {
        c->stats->moves++;
    }
}

/* a[i]와 a[j]를 맞바꾼다. buf 첫 칸을 거쳐 가므로 이동 3회 */
static inline void sortSwap(SortCtx *c, size_t i, size_t j) {
    sortMove(c, c->buf, sortAt(c, i));
    sortMove(c, sortAt(c, i), sortAt(c, j));
    sortMove(c, sortAt(c, j), c->buf);
}

/* 재귀 호출에 들어갈 때 깊이를 적어 둔다 */
static inline void sortEnterDepth(SortCtx *c, size_t depth) {
    if (c->stats != NULL && depth > c->stats->maxDepth) {
        c->stats->maxDepth = depth;
    }
}

#endif /* SORTCTX_H */
