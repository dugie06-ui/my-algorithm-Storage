/* 유닛 테스트 — 표준 C만 쓴다(프레임워크 없음).
 *
 * 구현 표(SORT_ALGORITHMS)를 훑으므로, 정렬을 하나 더 넣으면 그 순간부터
 * 같은 검사를 받는다. 하나라도 실패하면 0이 아닌 코드로 끝난다(make가 멈춘다).
 */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bench.h"
#include "sort.h"

static int checks = 0;
static int failures = 0;

static void check(int ok, const char *algo, const char *what) {
    checks++;
    if (!ok) {
        failures++;
    }
    printf("%s  %-10s %s\n", ok ? "ok  " : "FAIL", algo, what);
}

/* 테스트용 난수 (입력 생성기와 따로 둔다) */
static unsigned testRng = 12345u;
static int nextInt(void) {
    testRng = testRng * 1103515245u + 12345u;
    return (int)((testRng >> 8) & 0x7fffff);
}

/* input[0..n-1]을 f로 정렬한 결과가 qsort의 결과와 같은가 */
static int matchesQsort(SortFunction f, const int *input, size_t n) {
    size_t bytes = (n > 0 ? n : 1) * sizeof(int);
    int *mine = (int *)malloc(bytes);
    int *ref = (int *)malloc(bytes);
    if (mine == NULL || ref == NULL) {
        free(mine);
        free(ref);
        return 0;
    }
    if (n > 0) {
        memcpy(mine, input, n * sizeof(int));
        memcpy(ref, input, n * sizeof(int));
    }
    f(mine, n, sizeof(int), sortCompareInt, NULL);
    qsort(ref, n, sizeof(int), sortCompareInt);
    int ok = (n == 0) || memcmp(mine, ref, n * sizeof(int)) == 0;
    free(mine);
    free(ref);
    return ok;
}

static int sortsKind(SortFunction f, InputKind kind, size_t n) {
    Record *a = (Record *)malloc(n * sizeof *a);
    if (a == NULL) {
        return 0;
    }
    makeInput(a, n, kind, 7u);
    f(a, n, sizeof *a, recordCompare, NULL);
    int ok = recordsSorted(a, n);
    free(a);
    return ok;
}

/* --- 모든 정렬이 받는 검사 --------------------------------------------------- */

static void commonChecks(const SortAlgorithm *s) {
    const char *name = s->name;
    SortFunction f = s->sort;
    SortStats st;
    int buf[1200];

    int one[1] = {42};
    f(buf, 0, sizeof(int), sortCompareInt, &st);
    check(st.compares == 0 && st.moves == 0, name, "빈 배열 (n = 0): 아무것도 하지 않는다");
    f(one, 1, sizeof(int), sortCompareInt, &st);
    check(one[0] == 42 && st.compares == 0, name, "원소 1개: 그대로 둔다");

    int two[2] = {2, 1};
    f(two, 2, sizeof(int), sortCompareInt, NULL);
    check(two[0] == 1 && two[1] == 2, name, "원소 2개 역순");

    for (int i = 0; i < 1000; i++) buf[i] = nextInt();
    check(matchesQsort(f, buf, 1000), name, "섞인 배열 1,000개: qsort 결과와 같다");

    for (int i = 0; i < 1000; i++) buf[i] = i;
    check(matchesQsort(f, buf, 1000), name, "이미 정렬된 배열");

    for (int i = 0; i < 1000; i++) buf[i] = 1000 - i;
    check(matchesQsort(f, buf, 1000), name, "역순 배열");

    for (int i = 0; i < 1000; i++) buf[i] = nextInt() % 10;
    check(matchesQsort(f, buf, 1000), name, "중복 많은 배열 (값 0~9)");

    for (int i = 0; i < 1000; i++) buf[i] = 7;
    check(matchesQsort(f, buf, 1000), name, "모두 같은 값");

    int edge[8] = {0, INT_MAX, -1, INT_MIN, 5, INT_MIN, INT_MAX, -7};
    check(matchesQsort(f, edge, 8), name, "INT_MIN · INT_MAX · 음수가 섞인 배열");

    int allSizes = 1;
    for (size_t n = 0; n <= 300 && allSizes; n++) {
        for (size_t i = 0; i < n; i++) buf[i] = nextInt() % 50;
        allSizes = matchesQsort(f, buf, n);
    }
    check(allSizes, name, "크기 0~300 전부: qsort 결과와 같다 (경계 오류 찾기)");

    int shapes = 1;
    for (int k = 0; k < INPUT_KIND_COUNT; k++) {
        shapes = shapes && sortsKind(f, (InputKind)k, 2000);
    }
    check(shapes, name, "8바이트 레코드 · 입력 모양 다섯 가지를 모두 정렬");

    /* 안정성: 표에 적은 주장이 실측과 맞는가. 불안정하다고 적었다면
     * 실제로 순서가 뒤바뀌는 것까지 보여야 통과한다. */
    Record rec[2000];
    makeInput(rec, 2000, INPUT_FEW_UNIQUE, 99u);
    f(rec, 2000, sizeof rec[0], recordCompare, NULL);
    check(recordsStable(rec, 2000) == s->stable, name,
          s->stable ? "안정성: 같은 key의 순서가 지켜진다 (표의 주장과 일치)"
                    : "불안정성: 같은 key의 순서가 실제로 바뀐다 (표의 주장과 일치)");
}

/* --- 정렬마다의 검사 -------------------------------------------------------- */

static void quickChecks(void) {
    enum { N = 500 };
    int a[N];
    SortStats st;

    for (int i = 0; i < N; i++) a[i] = i;
    quickSortPivot = PIVOT_FIRST;
    quickSort(a, N, sizeof(int), sortCompareInt, &st);
    check(st.compares == (size_t)N * (N - 1) / 2 && st.maxDepth == N - 1, "quickSort",
          "정렬된 입력 + 첫 원소 피벗: 비교 n(n-1)/2, 깊이 n-1 (이론상 최악과 정확히 일치)");

    for (int p = 0; p < PIVOT_KIND_COUNT; p++) {
        char what[96];
        quickSortPivot = (QuickPivot)p;
        int ok = sortsKind(quickSort, INPUT_RANDOM, 3000) &&
                 sortsKind(quickSort, INPUT_SORTED, 3000) &&
                 sortsKind(quickSort, INPUT_FEW_UNIQUE, 3000);
        snprintf(what, sizeof what, "피벗 %s: 무작위·정렬됨·중복 입력을 모두 정렬", quickPivotName((QuickPivot)p));
        check(ok, "quickSort", what);
    }
    quickSortPivot = PIVOT_FIRST;

    for (int i = 0; i < N; i++) a[i] = i;
    quickSortPivot = PIVOT_MEDIAN3;
    quickSort(a, N, sizeof(int), sortCompareInt, &st);
    quickSortPivot = PIVOT_FIRST;
    check(st.maxDepth < 20, "quickSort", "정렬된 입력 + 세 값의 중앙값 피벗: 깊이가 log n 수준으로 준다");
}

static void mergeChecks(void) {
    enum { N = 1024 };
    int a[N];
    SortStats st;
    for (int i = 0; i < N; i++) a[i] = i;
    mergeSort(a, N, sizeof(int), sortCompareInt, &st);
    check(st.extraBytes == N * sizeof(int), "mergeSort", "추가 메모리 = n × 원소 크기");
    check(st.compares == (size_t)(N / 2) * 10, "mergeSort",
          "정렬된 입력 n = 1,024: 비교 (n/2)·log2 n = 5,120 (이론값과 일치)");
    check(st.moves == (size_t)2 * N * 10, "mergeSort", "이동 2n·log2 n: 원소마다 한 단계에 2회");
}

static void heapChecks(void) {
    enum { N = 1000 };
    int a[N];
    SortStats st;
    for (int i = 0; i < N; i++) a[i] = nextInt();
    heapSort(a, N, sizeof(int), sortCompareInt, &st);
    check(st.extraBytes == sizeof(int) && st.maxDepth == 1, "heapSort",
          "추가 메모리 = 원소 1칸, 재귀 없음 (깊이 1)");

    /* 보고서 2.3절의 예: [2a, 2b, 1]을 정렬하면 [1, 2b, 2a]가 된다 */
    Record r[3] = {{2, 0}, {2, 1}, {1, 2}};
    heapSort(r, 3, sizeof r[0], recordCompare, NULL);
    check(r[0].key == 1 && r[1].tag == 1 && r[2].tag == 0, "heapSort",
          "불안정 예시: [2a, 2b, 1] -> [1, 2b, 2a] (보고서의 손 추적과 일치)");
}

/* --- 측정 도구 자체의 검사 --------------------------------------------------- */

static void benchChecks(void) {
    enum { N = 2000 };
    Record a[N], b[N];
    int ok = 1;

    makeInput(a, N, INPUT_SORTED, 1u);
    ok = ok && recordsSorted(a, N);
    makeInput(a, N, INPUT_REVERSED, 1u);
    for (size_t i = 1; i < N; i++) ok = ok && a[i - 1].key > a[i].key;
    makeInput(a, N, INPUT_FEW_UNIQUE, 1u);
    for (size_t i = 0; i < N; i++) ok = ok && a[i].key >= 0 && a[i].key <= 9 && a[i].tag == (int)i;
    makeInput(a, N, INPUT_NEARLY, 1u);
    size_t inPlace = 0;
    for (size_t i = 0; i < N; i++) inPlace += (a[i].key == (int)i);
    ok = ok && !recordsSorted(a, N) && inPlace >= N - 2 * (N / 100);
    check(ok, "bench", "makeInput: 다섯 가지 입력이 설명대로 만들어진다");

    makeInput(a, N, INPUT_RANDOM, 5u);
    makeInput(b, N, INPUT_RANDOM, 5u);
    check(memcmp(a, b, sizeof a) == 0, "bench", "같은 씨앗이면 같은 입력 (재현성)");

    Record bad[2] = {{1, 1}, {1, 0}};
    check(!recordsStable(bad, 2), "bench", "recordsStable이 순서 위반을 잡는다");
}

int main(void) {
    for (size_t i = 0; i < SORT_ALGORITHM_COUNT; i++) {
        commonChecks(&SORT_ALGORITHMS[i]);
    }
    quickChecks();
    mergeChecks();
    heapChecks();
    benchChecks();

    printf("\n%d checks, %d failures\n", checks, failures);
    return failures == 0 ? 0 : 1;
}
