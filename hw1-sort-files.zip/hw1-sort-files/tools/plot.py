#!/usr/bin/env python3
"""보고서(report/)에 들어가는 그래프를 SVG로 그린다 — 표준 모듈만 쓴다.

    make charts                        # 측정을 새로 돌려 results.csv와 그래프를 만든다
    python3 tools/plot.py --from-csv   # 이미 있는 report/results.csv로 그래프만 다시 그린다

저장소 규약상 matplotlib 같은 외부 라이브러리를 쓰지 않는다. SVG는 글자로 된
그림 형식이라, 좌표를 계산해 문자열로 적으면 그대로 그림이 된다.
"""
import csv
import io
import math
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REPORT = ROOT / "report"
CSV_PATH = REPORT / "results.csv"

FONT = "'Noto Sans KR', 'Noto Sans CJK KR', 'Apple SD Gothic Neo', 'Malgun Gothic', sans-serif"
INK, MUTED, GRID = "#1f2937", "#6b7280", "#e5e7eb"

ALGOS = ["quickSort", "mergeSort", "heapSort"]
ALGO_LABEL = {a: a for a in ALGOS}
ALGO_COLOR = {"quickSort": "#2563eb", "mergeSort": "#f59e0b", "heapSort": "#16a34a"}

PIVOTS = ["first", "median3", "random"]
PIVOT_LABEL = {"first": "첫 원소 (수업 코드)", "median3": "세 값의 중앙값", "random": "무작위"}
PIVOT_COLOR = {"first": "#2563eb", "median3": "#7c3aed", "random": "#db2777"}

INPUTS = ["random", "sorted", "reversed", "nearly", "fewunique"]
INPUT_LABEL = {"random": "무작위", "sorted": "정렬됨", "reversed": "역순",
               "nearly": "거의 정렬됨", "fewunique": "중복 많음"}


# --- SVG 조각 ---------------------------------------------------------------

def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text_width(s, size):
    """글자 폭 어림. 한글은 정사각형에 가깝고 영문·숫자는 그보다 좁다."""
    return sum(size * (0.95 if ord(ch) > 0x2E80 else 0.6) for ch in str(s))


class Svg:
    def __init__(self, w, h):
        self.w, self.h, self.parts = w, h, []

    def text(self, x, y, s, size=12, anchor="start", weight="normal", fill=INK, rotate=None):
        tr = f' transform="rotate({rotate} {x:.1f} {y:.1f})"' if rotate is not None else ""
        self.parts.append(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" '
                          f'font-weight="{weight}" fill="{fill}"{tr}>{esc(s)}</text>')

    def line(self, x1, y1, x2, y2, stroke=GRID, width=1.0, dash=None):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                          f'stroke="{stroke}" stroke-width="{width}"{d}/>')

    def rect(self, x, y, w, h, fill, stroke=None, rx=0):
        s = f' stroke="{stroke}" stroke-width="1.5"' if stroke else ""
        self.parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{max(w, 0):.1f}" '
                          f'height="{max(h, 0):.1f}" rx="{rx}" fill="{fill}"{s}/>')

    def circle(self, x, y, r, fill, stroke=None):
        s = f' stroke="{stroke}" stroke-width="2"' if stroke else ""
        self.parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="{fill}"{s}/>')

    def polyline(self, pts, stroke, width=2.2):
        p = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
        self.parts.append(f'<polyline points="{p}" fill="none" stroke="{stroke}" '
                          f'stroke-width="{width}" stroke-linejoin="round"/>')

    def save(self, name):
        body = "\n".join(self.parts)
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" '
               f'width="{self.w}" height="{self.h}" font-family="{FONT}">\n'
               f'<rect width="100%" height="100%" fill="#ffffff"/>\n{body}\n</svg>\n')
        (REPORT / name).write_text(svg, encoding="utf-8")
        print(f"  report/{name}")


# --- 눈금과 숫자 --------------------------------------------------------------

def human(v):
    """158140 -> 158K, 49995000 -> 50M, 1e9 -> 1G, 1.823 -> 1.82"""
    if v >= 1e9:
        return f"{v / 1e9:.3g}G"
    if v >= 1e6:
        return f"{v / 1e6:.3g}M"
    if v >= 1e3:
        return f"{v / 1e3:.3g}K"
    return f"{v:.3g}"


def log_scale(lo, hi, p0, p1):
    a, b = math.log10(lo), math.log10(hi)
    return lambda v: p0 + (math.log10(v) - a) / (b - a) * (p1 - p0)


def lin_scale(lo, hi, p0, p1):
    return lambda v: p0 + (v - lo) / (hi - lo) * (p1 - p0)


def decade_bounds(values):
    vals = [v for v in values if v > 0]
    return 10 ** math.floor(math.log10(min(vals))), 10 ** math.ceil(math.log10(max(vals)))


def fit_slope(points):
    """log-log 평면에서 최소제곱 기울기 = 복잡도의 지수"""
    xs = [math.log10(x) for x, _ in points]
    ys = [math.log10(y) for _, y in points]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)


def header(svg, left, title, note):
    svg.text(left, 26, title, size=15, weight="bold")
    if note:
        svg.text(left, 45, note, size=11.5, fill=MUTED)


def legend(svg, x, y, items):
    """items: [(label, color)]"""
    for label, color in items:
        svg.rect(x, y - 10, 12, 12, color, rx=2)
        svg.text(x + 17, y, label, size=12)
        x += 17 + text_width(label, 12) + 22


# --- 그래프 종류 --------------------------------------------------------------

def grouped_bars(name, title, note, groups, group_label, series, series_label,
                 series_color, value, ylabel):
    """묶음 막대 · 로그 축. value(group, series) -> 수 (없으면 None)"""
    W, H = 780, 390
    left, right, top, bottom = 72, 16, 62, 70
    svg = Svg(W, H)
    header(svg, left, title, note)

    vals = [value(g, s) for g in groups for s in series]
    lo, hi = decade_bounds([v for v in vals if v])
    y = log_scale(lo, hi, H - bottom, top)
    k = round(math.log10(lo))
    while 10 ** k <= hi * 1.0001:
        yy = y(10 ** k)
        svg.line(left, yy, W - right, yy)
        svg.text(left - 8, yy + 4, human(10 ** k), size=11, anchor="end", fill=MUTED)
        k += 1
    svg.text(20, (top + H - bottom) / 2, ylabel, size=12, anchor="middle", rotate=-90, fill=MUTED)

    gw = (W - left - right) / len(groups)
    bw = min(40, gw * 0.84 / len(series))
    for gi, g in enumerate(groups):
        cx = left + gw * (gi + 0.5)
        x0 = cx - bw * len(series) / 2
        for si, s in enumerate(series):
            v = value(g, s)
            if not v:
                continue
            yy = y(v)
            svg.rect(x0 + si * bw + 1.5, yy, bw - 3, (H - bottom) - yy, series_color[s], rx=1.5)
            svg.text(x0 + si * bw + bw / 2, yy - 4, human(v), size=9.5, anchor="middle", fill=INK)
        svg.text(cx, H - bottom + 19, group_label[g], size=12.5, anchor="middle")
    svg.line(left, H - bottom, W - right, H - bottom, stroke="#9ca3af")
    legend(svg, left, H - 16, [(series_label[s], series_color[s]) for s in series])
    svg.save(name)


def line_chart(name, title, note, series, series_label, series_color, points,
               xlabel, ylabel, ylog=True, ylim=None, refs=(), show_slope=False):
    """꺾은선 · x는 로그 축. points(series) -> [(x, y)]"""
    W, H = 780, 400
    left, right, top, bottom = 72, 120 if refs else 20, 62, 74
    svg = Svg(W, H)
    header(svg, left, title, note)

    xs = sorted({x for s in series for x, _ in points(s)})
    x = log_scale(xs[0], xs[-1], left + 12, W - right - 12)
    ally = [yv for s in series for _, yv in points(s)]
    if ylog:
        lo, hi = decade_bounds(ally)
        y = log_scale(lo, hi, H - bottom, top)
        k = round(math.log10(lo))
        while 10 ** k <= hi * 1.0001:
            yy = y(10 ** k)
            svg.line(left, yy, W - right, yy)
            svg.text(left - 8, yy + 4, human(10 ** k), size=11, anchor="end", fill=MUTED)
            k += 1
    else:
        lo, hi, step = ylim
        y = lin_scale(lo, hi, H - bottom, top)
        v = lo
        while v <= hi + 1e-9:
            yy = y(v)
            svg.line(left, yy, W - right, yy)
            svg.text(left - 8, yy + 4, f"{v:g}", size=11, anchor="end", fill=MUTED)
            v += step
    for i, xv in enumerate(xs):
        if len(xs) > 8 and i % 2 == 1:
            continue  # 눈금이 촘촘하면 하나 걸러 적는다
        svg.text(x(xv), H - bottom + 18, human(xv), size=11, anchor="middle", fill=MUTED)
    svg.line(left, H - bottom, W - right, H - bottom, stroke="#9ca3af")
    svg.text((left + W - right) / 2, H - bottom + 38, xlabel, size=12, anchor="middle", fill=MUTED)
    svg.text(20, (top + H - bottom) / 2, ylabel, size=12, anchor="middle", rotate=-90, fill=MUTED)

    for value, label in refs:  # 이론값 기준선
        yy = y(value)
        svg.line(left, yy, W - right, yy, stroke="#9ca3af", width=1.2, dash="5 4")
        svg.text(W - right + 6, yy + 4, label, size=11, fill=MUTED)

    items = []
    for s in series:
        pts = points(s)
        svg.polyline([(x(a), y(b)) for a, b in pts], series_color[s])
        for a, b in pts:
            svg.circle(x(a), y(b), 3.2, series_color[s])
        label = series_label[s]
        if show_slope:
            label += f" (기울기 {fit_slope(pts):.2f})"
        items.append((label, series_color[s]))
    legend(svg, left, H - 12, items)
    svg.save(name)


# --- 힙 그림 (측정값이 아닌 설명용 그림) ------------------------------------------

def heap_figure():
    """배열 [9, 7, 3, 1, 4]와 그것이 뜻하는 완전 이진 트리를 나란히 그린다."""
    W, H = 780, 250
    svg = Svg(W, H)
    a = [9, 7, 3, 1, 4]
    svg.text(24, 28, "같은 배열, 두 가지 모습 — 배열 칸 i의 자식은 2i+1, 2i+2", size=15, weight="bold")

    # 왼쪽: 배열
    bx, by, cw = 40, 110, 56
    svg.text(bx, by - 30, "배열 (실제 메모리)", size=12.5, fill=MUTED)
    for i, v in enumerate(a):
        fill = "#dbeafe" if i == 0 else "#f3f4f6"
        svg.rect(bx + i * cw, by, cw - 6, 46, fill, stroke="#9ca3af", rx=4)
        svg.text(bx + i * cw + (cw - 6) / 2, by + 30, v, size=20, anchor="middle", weight="bold")
        svg.text(bx + i * cw + (cw - 6) / 2, by + 68, f"[{i}]", size=12, anchor="middle", fill=MUTED)
    svg.text(bx, by + 104, "포인터 없이 인덱스 계산만으로 부모·자식을 찾는다", size=12, fill=MUTED)

    # 오른쪽: 트리
    pos = {0: (590, 70), 1: (500, 140), 2: (680, 140), 3: (450, 210), 4: (550, 210)}
    for child in range(1, len(a)):
        parent = (child - 1) // 2
        (x1, y1), (x2, y2) = pos[parent], pos[child]
        svg.line(x1, y1, x2, y2, stroke="#9ca3af", width=2)
    for i, (px, py) in pos.items():
        svg.circle(px, py, 22, "#dbeafe" if i == 0 else "#ffffff", stroke="#2563eb")
        svg.text(px, py + 7, a[i], size=18, anchor="middle", weight="bold")
        svg.text(px + 30, py - 14, f"[{i}]", size=11, fill=MUTED)
    svg.text(400, 70, "최대 힙 (논리적 모습)", size=12.5, fill=MUTED)
    svg.text(640, 222, "모든 부모 ≥ 자식", size=12, fill="#2563eb")
    svg.save("heap-array-tree.svg")


# --- 실행 ------------------------------------------------------------------

def load_rows(from_csv):
    if from_csv:
        text = CSV_PATH.read_text(encoding="utf-8")
    else:
        exe = ROOT / "src" / "main.out"
        print("측정 중... (./src/main.out --csv, 20초 안팎)")
        text = subprocess.run([str(exe), "--csv"], check=True, capture_output=True,
                              text=True).stdout
        CSV_PATH.write_text(text, encoding="utf-8")
        print("  report/results.csv")
    return list(csv.DictReader(io.StringIO(text)))


def main():
    REPORT.mkdir(exist_ok=True)
    rows = load_rows("--from-csv" in sys.argv)

    def pick(exp, **kw):
        return [r for r in rows if r["experiment"] == exp
                and all(r[k] == v for k, v in kw.items())]

    def one(exp, field, **kw):
        found = pick(exp, **kw)
        return float(found[0][field]) if found else None

    # 1. 입력 모양별
    for field, fname, ylabel, what in [("ms", "shape-time.svg", "시간 (ms, 로그 축)", "걸린 시간"),
                                       ("compares", "shape-compares.svg", "비교 횟수 (로그 축)", "비교 횟수"),
                                       ("moves", "shape-moves.svg", "이동 횟수 (로그 축)", "이동 횟수")]:
        grouped_bars(fname, f"입력 모양별 {what} (n = 10,000)",
                     "로그 축: 눈금 한 칸이 10배다. 막대 위 숫자가 실제 값", INPUTS, INPUT_LABEL,
                     ALGOS, ALGO_LABEL, ALGO_COLOR,
                     lambda g, s, f=field: one("shape", f, input=g, algorithm=s), ylabel)

    # 2. n을 키우며 (무작위)
    def growth(field):
        return lambda s: [(float(r["n"]), float(r[field])) for r in pick("growth", algorithm=s)]

    line_chart("growth-time.svg", "n을 키우며 — 걸린 시간 (무작위 입력)",
               "로그-로그 축: 직선의 기울기가 복잡도의 지수다 (n log n이면 1보다 조금 크다)",
               ALGOS, ALGO_LABEL, ALGO_COLOR, growth("ms"), "n (원소 개수)", "시간 (ms)",
               show_slope=True)

    def ratio(s):
        return [(float(r["n"]), float(r["compares"]) / (float(r["n"]) * math.log2(float(r["n"]))))
                for r in pick("growth", algorithm=s)]

    line_chart("growth-ratio.svg", "비교 횟수 ÷ n·log₂n — 같은 O(n log n)의 '상수'",
               "세 정렬 모두 O(n log n)이지만 앞에 붙는 상수가 다르다. 점선은 이론상 극한값",
               ALGOS, ALGO_LABEL, ALGO_COLOR, ratio, "n (원소 개수)", "비교 ÷ n·log₂n",
               ylog=False, ylim=(0.0, 2.2, 0.5),
               refs=[(1.0, "1 (병합)"), (2 * math.log(2), "1.39 (퀵)"), (2.0, "2 (힙)")])

    # 3. 정렬된 입력에서 n을 키우며
    line_chart("worst-compares.svg", "정렬된 입력에서 n을 키우며 — 비교 횟수",
               "퀵 정렬(첫 원소 피벗)만 기울기 2, 곧 O(n²)이 된다",
               ALGOS, ALGO_LABEL, ALGO_COLOR,
               lambda s: [(float(r["n"]), float(r["compares"])) for r in pick("worst", algorithm=s)],
               "n (원소 개수)", "비교 횟수", show_slope=True)

    # 4. 피벗 실험
    grouped_bars("pivot-compares.svg", "퀵 정렬의 피벗 고르는 법 — 비교 횟수 (n = 10,000)",
                 "피벗을 바꾸면 정렬·역순·거의 정렬은 고쳐지지만, 중복 많음은 그대로다",
                 INPUTS, INPUT_LABEL, PIVOTS, PIVOT_LABEL, PIVOT_COLOR,
                 lambda g, s: one("pivot", "compares", input=g, pivot=s), "비교 횟수 (로그 축)")

    heap_figure()


if __name__ == "__main__":
    main()
