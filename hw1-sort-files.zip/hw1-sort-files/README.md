# 정렬 비교 — 퀵 · 병합 · 힙

2026-2 고급알고리즘(SIT2001-01) 과제 1. 수업에서 배운 **퀵 정렬 · 병합 정렬**과
배우지 않은 **힙 정렬**을 하나의 공통 인터페이스로 묶고, 같은 입력과 같은 잣대로
시간 · 비교 횟수 · 이동 횟수 · 추가 메모리 · 재귀 깊이 · 안정성을 비교했다.

- 보고서: [report/REPORT.md](report/REPORT.md) — 힙 정렬을 AI로 학습한 내용은 2.3절
- 이 저장소는 [lec-algorithm/algorithm-env](https://github.com/lec-algorithm/algorithm-env) 템플릿으로 만들었다.
  C 컴파일러와 make가 든 컨테이너(Codespaces 또는 `docker compose exec lab bash`) 안에서 돌린다.

## 실행

| 명령 | 하는 일 |
| --- | --- |
| `make run` | 실험 네 가지(입력 모양 · n 키우기 · 최악 · 피벗)를 돌려 비교 표를 찍는다. 20초 안팎 |
| `make test` | 유닛 테스트 49개. 모두 통과해야 한다 |
| `make charts` | 측정을 다시 돌려 `report/results.csv`와 그래프(SVG)를 새로 만든다 |
| `make clean` | 빌드 산출물(`*.out`) 정리 |

```console
$ make test
...
49 checks, 0 failures

$ make run
[무작위 · n = 10,000]
  알고리즘            시간(ms)           비교           이동  추가 메모리  재귀 깊이   정렬   안정
  quickSort              1.774        158,140        211,818          8 B         32    yes      -
  mergeSort              2.209        120,408        267,232     80,000 B         14    yes      -
  heapSort               1.959        235,283        154,134          8 B          1    yes      -
...
```

시간은 돌릴 때마다 조금씩 다르지만, 비교 · 이동 횟수는 입력의 씨앗이 고정되어 있어 어디서 돌려도 같다.

## 구조

```text
src/
  sort.h          공통 인터페이스 (SortAlgorithm: 함수 포인터 + 복잡도 + 안정성 주장)
  sortctx.h       구현 전용 도구: 세면서 비교 · 이동 · 교환
  sort.c          공통 도구와 구현 표 SORT_ALGORITHMS
  quickSort.c     퀵 정렬 — 수업 코드(첫 원소 피벗) + 피벗 실험용 옵션
  mergeSort.c     병합 정렬 — 수업 코드
  heapSort.c      힙 정렬 — 새로 학습해 구현
  bench.h/.c      입력 생성(5가지 모양), 시간 측정(중앙값), 안정성 판정
  main.c          실험 실행기 (--csv를 주면 CSV로 출력)
tests/test_sort.c 유닛 테스트 (표준 C만)
tools/plot.py     CSV → SVG 그래프 (표준 모듈만)
report/           보고서, 그래프, 측정값 원본 results.csv
```

정렬을 하나 더 넣으려면 파일을 하나 만들고 `sort.c`의 구현 표에 한 줄, `Makefile`의
`SORT_SRC`에 한 단어를 더한다. 실험과 테스트는 표를 훑으므로 고칠 필요가 없다.
